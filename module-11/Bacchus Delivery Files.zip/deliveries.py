import mysql.connector
from mysql.connector import errorcode

config = {
        'user': "",
        'password': "",
        'host': 'localhost',
        'database': 'Bacchus',
        'raise_on_warnings': True
    }

db = mysql.connector.connect(**config)
print("\nDatabase user (root) connected to MySQL on host (localhost) with database (Bacchus).")


cursor = db.cursor()

try:
    # Define the SQL query to select delivery dates and actual delivery dates
    product_query = "SELECT delivery_date, actual_delivery_date FROM Supplier1Deliveries;"
    
    # Execute the SQL query
    cursor.execute(product_query)
    
    # Fetch all rows from the result set
    products = cursor.fetchall()

    print("\n--DISPLAYING Delivery Information REPORT--\n")
    for product in products:
        print("Delivery Date: {}\nActual Delivery Date: {}\n".format(product[0], product[1]))

finally:
    # Close the cursor and database connection
    cursor.close()
    db.close()